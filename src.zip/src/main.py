#! /usr/bin/env python3
import operator

from environment import Environment
from polygon import Polygon
from vector2d import Vector2D
import sys

class Node:
    def __init__(self,x,y):
        self.path=[]
        self.vector=Vector2D(x,y)

def calculateKB(vector1,vector2):
    if vector1.x!=vector2.x :
        k = (vector1.y - vector2.y) / (vector1.x - vector2.x)
        b = vector1.y - k * vector1.x
    else:
        k=sys.maxsize
        b=vector1.x
    return k, b

def isreachable(vector1,vector2,sides):
    k,b=calculateKB(vector1,vector2)
    mark=0
    # print("vector1 :",vector1.x,vector1.y)
    # print("vector2 :",vector2.x,vector2.y)
    # print("k :",k,"b: ",b)
    for i in range(len(sides)):
        p=sides[i]
        for j in range(len(p.sides)):
            vector3 = p.sides[j][0]
            vector4 = p.sides[j][1]
            k1 = p.sides[j][2]
            b1 = p.sides[j][3]
            if k1 != k:
                if k == sys.maxsize :
                    x=b
                    y=k1*x+b1
                    if x != vector1.x and x != vector2.x and y != vector1.y and y != vector2.y:
                        if x >= min(vector1.x, vector2.x) and x <= max(vector1.x, vector2.x) and x >= min(vector3.x,
                                                                                                          vector4.x) and x <= max(
                            vector3.x, vector4.x):
                            if y >= min(vector1.y, vector2.y) and y <= max(vector1.y, vector2.y) and y >= min(vector3.y,
                                                                                                              vector4.y) and y <= max(
                                vector3.y, vector4.y):
                                mark = 1
                                break
                else:
                    x = round((b1 - b) / (k - k1),6)
                    y = round(k * x + b,6)
                    if x!=vector1.x and x!=vector2.x and y!=vector1.y and y!=vector2.y:
                        #print(x,y,vector1.x,vector1.y,vector2.x,vector2.y,vector3.x,vector3.y,vector4.x,vector4.y)
                        if x >= min(vector1.x, vector2.x) and x <= max(vector1.x, vector2.x) and x >= min(vector3.x,
                                                                                                       vector4.x) and x <= max(
                                vector3.x, vector4.x):
                            if y >= min(vector1.y, vector2.y) and y <= max(vector1.y, vector2.y) and y >= min(vector3.y,
                                                                                                           vector4.y) and y <= max(
                                    vector3.y, vector4.y):
                                mark = 1
                                # print(x,y,vector3.x,vector3.y,vector4.x,vector4.y)
                                # print(x<max(vector1.x, vector2.x))
                                break
    if mark==0:
        return True
    else:
        return False

def calculateSide(obstacles):
    sides=[]
    for i in range(len(obstacles)):
        p=obstacles[i]
        for j in range(len(p.vertices)):
            for q in range(j+1,len(p.vertices)):
                k, b = calculateKB(p.vertices[j], p.vertices[q])
                list1 = [p.vertices[j], p.vertices[q], k, b]
                p.sides.append(list1)
        sides.append(p)

    return sides

def cost(path):
    costsum=0
    currentpos=Vector2D(0,0)
    for i in range(len(path)):
        vec=path[i]
        costsum+=currentpos.dist(vec)
        currentpos=vec
    return costsum

def greedySearch(env):
    #
    # TODO: return a path from start to goal using greedy search
    #
    currentPos = Node(env.start.x, env.start.y)
    currentPos.path.append(env.start)
    path = []
    goal = env.goal
    sides = env.sides
    list1 = [currentPos, 0, 0, 0]
    openlist = [list1]
    closelist = []
    while len(openlist) != 0:
        openlist.sort(key=operator.itemgetter(2))
        checklist = openlist[0]
        if checklist[0].vector.x == goal.x and checklist[0].vector.y == goal.y:
            path = checklist[0].path
            print("Find the goal!!!")
            break
        openlist.pop(0)
        closelist.append(checklist)
        successors = []
        for i in range(len(env.obstacles)):
            p = env.obstacles[i]
            for j in range(len(p.vertices)):
                if p.vertices[j].x != checklist[0].vector.x or p.vertices[j].y != checklist[0].vector.y:
                    if isreachable(p.vertices[j], checklist[0].vector, sides):
                        successors.append(p.vertices[j])
        # for i in range(len(successors)):
        #     print(successors[i].x,successors[i].y)
        if isreachable(goal, checklist[0].vector, sides):
            successors.append(goal)
        for i in range(len(successors)):
            h = successors[i].dist(goal)
            g = successors[i].dist(checklist[0].vector) + checklist[1]
            f = g + h
            node = Node(successors[i].x, successors[i].y)
            for j in range(len(checklist[0].path)):
                node.path.append(checklist[0].path[j])
            node.path.append(successors[i])
            list2 = [node, g, h, f]
            mark = 0
            for j in range(len(closelist)):
                if node.vector.x == closelist[j][0].vector.x and node.vector.y == closelist[j][0].vector.y:
                    list2 = []
            if len(list2) == 0:
                continue
            else:
                for j in range(len(openlist)):
                    if node.vector.x == openlist[j][0].vector.x and node.vector.y == openlist[j][0].vector.y:
                        mark = 1
                        if list2[2] < openlist[j][2]:
                            openlist.pop(j)
                            openlist.append(list2)
                if mark == 0:
                    openlist.append(list2)
    print("gready search cost: ",cost(path))
    return path

def uniformCostSearch(env):
    #
    # TODO
    #
    print("please wait...")
    currentPos = Node(env.start.x, env.start.y)
    currentPos.path.append(env.start)
    path = []
    goal = env.goal
    sides = env.sides
    list1 = [currentPos, 0, 0, 0]
    openlist = [list1]
    closelist = []
    while len(openlist) != 0:
        # print("openlist size: ",len(openlist))
        openlist.sort(key=operator.itemgetter(1))
        checklist = openlist[0]
        if checklist[0].vector.x == goal.x and checklist[0].vector.y == goal.y:
            path = checklist[0].path
            print("Find the goal!!!")
            break
        openlist.pop(0)
        closelist.append(checklist)
        successors = []
        for i in range(len(env.obstacles)):
            p = env.obstacles[i]
            for j in range(len(p.vertices)):
                if p.vertices[j].x != checklist[0].vector.x or p.vertices[j].y != checklist[0].vector.y:
                    if isreachable(p.vertices[j], checklist[0].vector, sides):
                        successors.append(p.vertices[j])
        # for i in range(len(successors)):
        #     print(successors[i].x,successors[i].y)
        if isreachable(goal, checklist[0].vector, sides):
            successors.append(goal)
        for i in range(len(successors)):
            h = successors[i].dist(goal)
            g = successors[i].dist(checklist[0].vector) + checklist[1]
            f = g + h
            node = Node(successors[i].x, successors[i].y)
            for j in range(len(checklist[0].path)):
                node.path.append(checklist[0].path[j])
            node.path.append(successors[i])
            list2 = [node, g, h, f]
            mark = 0
            for j in range(len(closelist)):
                if node.vector.x == closelist[j][0].vector.x and node.vector.y == closelist[j][0].vector.y:
                    list2 = []
            if len(list2) == 0:
                continue
            else:
                for j in range(len(openlist)):
                    if node.vector.x == openlist[j][0].vector.x and node.vector.y == openlist[j][0].vector.y:
                        mark = 1
                        if list2[1] < openlist[j][1]:
                            openlist.pop(j)
                            openlist.append(list2)
                if mark == 0:
                    openlist.append(list2)
    print("uniform search cost: ",cost(path))
    return path

def astarSearch(env):
    #
    # TODO
    #
    print("please wait...")
    currentPos = Node(env.start.x,env.start.y)
    currentPos.path.append(env.start)
    path = []
    goal = env.goal
    sides = env.sides
    list1=[currentPos,0,0,0]
    openlist=[list1]
    closelist=[]
    # print(isreachable(Vector2D(94.320898 ,53.419979),Vector2D(73.411965 ,16.566885),sides))
    while len(openlist)!=0:
        # print("openlist size: ", len(openlist))
        openlist.sort(key=operator.itemgetter(3))
        checklist=openlist[0]
        if checklist[0].vector.x==goal.x and checklist[0].vector.y==goal.y:
            path=checklist[0].path
            print("Find the goal!!!")
            break
        openlist.pop(0)
        closelist.append(checklist)
        successors = []
        for i in range(len(env.obstacles)):
            p = env.obstacles[i]
            for j in range(len(p.vertices)):
                if p.vertices[j].x != checklist[0].vector.x or p.vertices[j].y != checklist[0].vector.y:
                    if isreachable(p.vertices[j],checklist[0].vector, sides):
                        successors.append(p.vertices[j])
        if isreachable(goal, checklist[0].vector, sides):
            successors.append(goal)
        # print("############################################")
        # print("current x:",checklist[0].vector.x,"current y:",checklist[0].vector.y)
        # for i in range(len(successors)):
        #     print(successors[i].x,successors[i].y)
        # print("#############################################")
        for i in range(len(successors)):
            h=successors[i].dist(goal)
            g=successors[i].dist(checklist[0].vector)+checklist[1]
            f = g+h
            node=Node(successors[i].x,successors[i].y)
            for j in range(len(checklist[0].path)):
                node.path.append(checklist[0].path[j])
            node.path.append(successors[i])
            list2=[node,g,h,f]
            mark=0
            for j in range(len(closelist)):
                if node.vector.x==closelist[j][0].vector.x and node.vector.y==closelist[j][0].vector.y:
                    list2=[]
            if len(list2)==0:
                continue
            else:
                for j in range(len(openlist)):
                    if node.vector.x ==openlist[j][0].vector.x and node.vector.y==openlist[j][0].vector.y:
                        mark=1
                        if list2[3]<openlist[j][3]:
                            openlist.pop(j)
                            openlist.append(list2)
                if mark==0:
                    openlist.append(list2)
    print("A* search cost: ",cost(path))
    return path

if __name__ == '__main__':
    env = Environment('output/environment.txt')
    print("Loaded an environment with {} obstacles.".format(len(env.obstacles)))
    searches = {
        'greedy': greedySearch,
        'uniformcost': uniformCostSearch,
        'astar': astarSearch
    }
    env.sides=calculateSide(env.obstacles)
    for name, fun in searches.items():
        print("Attempting a search with " + name)
        Environment.printPath(name, fun(env))
